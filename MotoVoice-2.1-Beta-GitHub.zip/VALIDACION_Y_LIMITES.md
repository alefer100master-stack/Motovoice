# MotoVoice 2.1 Beta — cambios auditables

- Servicio de micrófono iniciado por el usuario, con bloqueo parcial de CPU (WAKE_LOCK) mientras está activo; se libera al detenerlo.
- Acceso directo a ajustes de optimización de batería de Android.
- Reintentos de reconocimiento menos agresivos y tratamiento específico de errores.
- Mantiene reconocimiento de voz nativo, contactos, lectura/respuesta de notificaciones y búsquedas.

## Restricciones que NO se han resuelto
- No existe API pública fiable para iniciar automáticamente llamadas de voz de WhatsApp.
- YouTube/YouTube Music pueden exigir desbloquear la interfaz.
- La captura de audio por micrófono Bluetooth, continuidad del reconocedor con pantalla apagada y la respuesta por RemoteInput requieren pruebas en el S24 Ultra; WAKE_LOCK no garantiza ninguna de ellas.
- No hay traducción automática implementada.
- No se ha ejecutado compilación Android completa ni prueba física en este entorno.

## Prueba mínima
1. Conceder permisos y acceso a notificaciones.
2. Iniciar modo conducción con el teléfono desbloqueado.
3. Bloquear pantalla y comprobar reconocimiento por intercomunicador.
4. Probar llamada celular, lectura y respuesta a WhatsApp, y búsqueda musical por separado.
