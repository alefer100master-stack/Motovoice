package com.motovoice.ride

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(11,18,32)
    private val panel = Color.rgb(23,35,54)
    private val accent = Color.rgb(82,226,177)
    private val white = Color.rgb(241,246,252)
    private val muted = Color.rgb(159,174,194)
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(35), dp(24), dp(28)) }
        scroll.addView(root)
        root.addView(text("MOTO  /  VOICE", 13, accent, true))
        root.addView(space(20))
        root.addView(text("Tu copiloto,\nsin tocar el móvil.", 32, white, true))
        root.addView(space(12))
        root.addView(text("Asistente de conducción para llamadas, WhatsApp y música. La pantalla puede permanecer bloqueada en acciones compatibles.", 15, muted))
        root.addView(space(25))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(22)); background = rounded(panel, 24) }
        hero.addView(text("●  MODO CONDUCCIÓN", 12, accent, true))
        hero.addView(space(10))
        status = text("Listo para configurar", 19, white, true)
        hero.addView(status)
        hero.addView(space(16))
        hero.addView(button("INICIAR MODO CONDUCCIÓN", true) { startRide() })
        hero.addView(space(8))
        hero.addView(button("DETENER", false) { stopService(Intent(this, RideService::class.java)); status.text = "Servicio detenido" })
        root.addView(hero)
        root.addView(space(26))
        root.addView(text("CONFIGURACIÓN", 13, accent, true))
        root.addView(space(12))
        root.addView(button("1  Conceder permisos", false) { askPermissions() })
        root.addView(space(10))
        root.addView(button("2  Acceso a notificaciones", false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        root.addView(space(10))
        root.addView(button("3  Ajustes de Bluetooth", false) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        root.addView(space(10))
        root.addView(button("4  Optimización de batería", false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(space(24))
        root.addView(text("COMANDOS DISPONIBLES", 13, accent, true))
        root.addView(space(12))
        listOf("Llama a [contacto]", "Llama por WhatsApp a [contacto] (abre chat)", "Quién me escribió / Leer WhatsApp", "Responder → dictar → confirmar", "Busca [canción] en YouTube", "Abre WhatsApp / YouTube / YouTube Music", "Detener MotoVoice").forEach {
            root.addView(text("  •  $it", 15, white)); root.addView(space(10))
        }
        root.addView(space(15))
        root.addView(text("SEGURIDAD · No se almacena el PIN. No se contestan llamadas entrantes por voz. El botón físico del intercomunicador conserva esa función. Algunas acciones requieren desbloqueo.", 13, muted))
        setContentView(scroll)
    }
    private fun askPermissions() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 31) list.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray(), 10)
    }
    private fun startRide() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPermissions(); status.text = "Concede el permiso del micrófono"; return }
        try { startForegroundService(Intent(this, RideService::class.java)); status.text = "Modo conducción iniciado" }
        catch (e: Exception) { status.text = "No se pudo iniciar: ${e.javaClass.simpleName}" }
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun button(s: String, primary: Boolean, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(if(primary) bg else white); gravity = Gravity.CENTER
        background = rounded(if(primary) accent else Color.rgb(42,57,77), 14)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
        setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun space(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
