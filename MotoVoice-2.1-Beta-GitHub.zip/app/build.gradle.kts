plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.motovoice.ride"
    compileSdk = 35
    defaultConfig { applicationId = "com.motovoice.ride"; minSdk = 29; targetSdk = 35; versionCode = 3; versionName = "2.1.0-beta" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
