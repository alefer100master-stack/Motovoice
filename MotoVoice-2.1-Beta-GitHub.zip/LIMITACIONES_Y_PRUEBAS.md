# MotoVoice 2.0 beta - alcance real

- Reconocimiento de voz: SpeechRecognizer Android con preferencia por reconocimiento local si el sistema lo ofrece; alternativa predeterminada si no existe modelo local. No equivale a escucha continua garantizada: Android puede limitar sesiones y servicios.
- WhatsApp: lectura de notificaciones recibidas después de conceder acceso; dictado de respuesta y confirmación, sujeto a RemoteInput.
- Llamadas celulares: usa ACTION_CALL con permisos, sujeto a restricciones del sistema.
- Llamadas WhatsApp: se abre el chat del contacto como alternativa; NO existe API pública estable para iniciar llamada sin intervención.
- YouTube: abre URL de búsqueda, NO garantiza reproducción con bloqueo.
- Traducción: NO implementada; requiere modelo de traducción descargable.
- No se ha ejecutado compilación Android en este entorno. GitHub Actions debe compilar y el S24 Ultra debe validar funcionamiento.
