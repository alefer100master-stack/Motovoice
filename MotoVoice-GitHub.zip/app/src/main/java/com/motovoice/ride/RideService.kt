package com.motovoice.ride

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.text.Normalizer
import java.util.Locale

class RideService : Service(), TextToSpeech.OnInitListener {
    companion object { const val CHANNEL = "ride"; const val ACTION_STOP = "stop" }
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var active = false
    private var pendingReply: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Modo conducción", NotificationManager.IMPORTANCE_LOW))
        tts = TextToSpeech(this, this)
    }
    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; if (ready) tts?.language = Locale("es", "CO") }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val stop = Intent(this, RideService::class.java).setAction(ACTION_STOP)
        val pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("MotoVoice activo")
            .setContentText("Modo conducción · pulsa Detener para finalizar")
            .setOngoing(true).addAction(Notification.Action.Builder(null, "Detener", pi).build()).build()
        startForeground(21, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        active = true
        speak("MotoVoice activado. Dime qué necesitas.")
        return START_NOT_STICKY
    }
    private fun speak(message: String) {
        if (!active) return
        recognizer?.cancel(); listening = false
        if (!ready) { handler.postDelayed({ if (active) speak(message) }, 600); return }
        // Register completion listener before speaking.
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { handler.postDelayed({ listen() }, 350) }
            override fun onError(utteranceId: String?) { handler.postDelayed({ listen() }, 800) }
        })
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "mv-${System.nanoTime()}")
    }
    private fun listen() {
        if (!active || listening || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { active = false; stopSelf(); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { listening = false; if (active) handler.postDelayed({ listen() }, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1800 else 900) }
            override fun onResults(results: Bundle?) { listening = false; val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (command != null) execute(command) else listen() }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        listening = true
        try { recognizer?.startListening(intent) } catch (_: Exception) { listening = false; handler.postDelayed({ listen() }, 1200) }
    }
    private fun norm(s: String) = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").trim()
    private fun execute(original: String) {
        val c = norm(original)
        val draft = pendingReply
        if (draft != null) {
            pendingReply = null
            when {
                c.contains("confirm") || c == "si" || c.contains("enviar") -> speak(if (MessageListener.reply(draft)) "Respuesta enviada a la notificación de WhatsApp." else "No pude enviar la respuesta. Comprueba la notificación.")
                else -> speak("Envío cancelado.")
            }
            return
        }
        when {
            c.startsWith("llama a ") || c.startsWith("llamar a ") -> call(original.substringAfter(" a ").trim())
            c.contains("quien me escribio") || c.contains("ultimo mensaje") || c.contains("leer whatsapp") -> {
                val m = MessageListener.lastMessage
                speak(if (m == null) "No hay mensajes nuevos de WhatsApp disponibles." else "Te escribió ${m.sender}. Dice: ${m.body}")
            }
            c.startsWith("responder ") || c.startsWith("responde ") -> {
                if (MessageListener.lastMessage == null) speak("No hay una notificación de WhatsApp para responder.")
                else {
                    val body = original.substringAfter(' ').trim()
                    pendingReply = body
                    speak("Voy a responder: $body. Di confirmar o cancelar.")
                }
            }
            c.startsWith("busca ") || c.startsWith("buscar ") || c.startsWith("pon ") -> {
                val q = original.substringAfter(' ').trim()
                val url = "https://music.youtube.com/search?q=" + Uri.encode(q)
                open(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Abrí la búsqueda de música. Es posible que debas desbloquear para interactuar.")
            }
            c.startsWith("abre ") || c.startsWith("abrir ") -> {
                val target = norm(original.substringAfter(' '))
                val pkg = when { target.contains("whatsapp") -> "com.whatsapp"; target.contains("youtube music") -> "com.google.android.apps.youtube.music"; target.contains("youtube") -> "com.google.android.youtube"; else -> null }
                val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                if (launch == null) speak("No encuentro esa aplicación entre las compatibles.") else open(launch, "Intenté abrir la aplicación. Android puede exigir desbloqueo.")
            }
            c.contains("detener motovoice") || c.contains("terminar modo") -> { speak("Modo conducción finalizado."); handler.postDelayed({ stopSelf() }, 1400) }
            else -> speak("No entendí la orden. Puedes llamar a un contacto, leer WhatsApp, responder un mensaje o buscar música.")
        }
    }
    private fun call(name: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) { speak("Concede los permisos de teléfono y contactos."); return }
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        val found = mutableListOf<Pair<String,String>>()
        contentResolver.query(uri, projection, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { cursor ->
            while (cursor.moveToNext() && found.size < 3) found.add(cursor.getString(0) to cursor.getString(1))
        }
        when (found.size) {
            0 -> speak("No encontré el contacto $name")
            1 -> {
                try { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(found[0].second))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Llamando a ${found[0].first}") }
                catch (_: Exception) { speak("Android no permitió iniciar la llamada.") }
            }
            else -> speak("Encontré varios contactos con ese nombre. Usa un nombre más específico.")
        }
    }
    private fun open(intent: Intent, success: String) {
        try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak(success) }
        catch (_: Exception) { speak("Android no permitió abrir esa aplicación desde este estado.") }
    }
    override fun onDestroy() {
        active = false; handler.removeCallbacksAndMessages(null)
        recognizer?.cancel(); recognizer?.destroy(); tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
