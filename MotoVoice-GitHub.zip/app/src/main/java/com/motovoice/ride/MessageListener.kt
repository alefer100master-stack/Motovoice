package com.motovoice.ride

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

class MessageListener : NotificationListenerService() {
    data class Message(val sender: String, val body: String, val notificationKey: String)
    companion object {
        @Volatile var lastMessage: Message? = null
        private val pending = ConcurrentHashMap<String, Pair<PendingIntent, Array<RemoteInput>>>()
        fun reply(text: String): Boolean {
            val msg = lastMessage ?: return false
            val pair = pending[msg.notificationKey] ?: return false
            return try {
                val intent = android.content.Intent()
                val bundle = android.os.Bundle()
                pair.second.forEach { bundle.putCharSequence(it.resultKey, text) }
                RemoteInput.addResultsToIntent(pair.second, intent, bundle)
                pair.first.send(null, 0, intent)
                true
            } catch (_: Exception) { false }
        }
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return
        val extras = sbn.notification.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (sender.isBlank() || body.isBlank()) return
        val action = sbn.notification.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        if (action != null) pending[sbn.key] = action.actionIntent to action.remoteInputs
        lastMessage = Message(sender, body, sbn.key)
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { pending.remove(sbn.key) }
}
