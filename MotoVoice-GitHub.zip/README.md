# MotoVoice · Android

Proyecto Android nativo Kotlin para Samsung Galaxy S24 Ultra y otros Android 10+.

## IMPORTANTE: subir ZIP a GitHub

**GitHub NO descomprime automáticamente un ZIP subido por la interfaz web.** Debes **extraer el ZIP** y subir **todo el contenido extraído**, incluida la carpeta oculta `.github/workflows/android.yml`, directamente a la raíz del repositorio. Si subes solo `MotoVoice-GitHub.zip`, no se ejecutará ningún workflow.

### Pasos (sin PC)
1. En Android, abre Mis archivos → Descargas → selecciona el ZIP → Extraer.
2. En GitHub crea un repositorio vacío y elige **Add file → Upload files**. En móvil, subir carpetas completas desde navegador puede no ser posible; utiliza GitHub desde un PC o un cliente Git que conserve directorios y archivos ocultos.
3. Verifica que en la raíz de GitHub estén `settings.gradle.kts`, `build.gradle.kts`, `app/` y `.github/workflows/android.yml`.
4. En GitHub → Actions → **Android APK** → Run workflow, o realiza un push a `main`.
5. Descarga el artefacto `MotoVoice-debug-apk` de la ejecución exitosa; contiene `app-debug.apk`.

No necesitas añadir secretos de firma para la APK **debug**. La APK debug es para pruebas, no para Play Store. Para una APK release firmada se necesita un keystore propio y un flujo seguro de firma.

## Funciones implementadas
- Interfaz oscura con botones de inicio/detención, permisos, ajustes de notificaciones y Bluetooth.
- Servicio de micrófono en primer plano iniciado manualmente desde la actividad visible.
- Reconocimiento de voz Android (depende del servicio de reconocimiento instalado) y respuesta hablada TTS en español.
- Llamadas celulares salientes por nombre de contacto (solo coincidencia única).
- Lectura del último texto de una notificación de WhatsApp recibida mientras el listener está activo.
- Respuesta dictada a través de `RemoteInput` cuando WhatsApp incluye acción compatible, con confirmación.
- Búsqueda de YouTube Music por URL y apertura de tres apps compatibles.
- No contesta llamadas entrantes por voz; el intercomunicador gestiona esas llamadas.

## Limitaciones verificables
- **No hay integración garantizada con el botón físico del intercomunicador**, ni enrutamiento forzado del micrófono Bluetooth. Requiere pruebas por modelo y posiblemente una implementación de AudioManager.setCommunicationDevice.
- Android/Samsung puede restringir reconocimiento de voz, audio y apertura de actividades con pantalla bloqueada. El servicio en primer plano no elimina esas restricciones.
- El reconocimiento continuo reinicia sesiones y puede consumir batería; **no implementa wake word local**. Inicia el servicio antes de bloquear el dispositivo.
- WhatsApp llamadas salientes/entrantes **no implementadas**: no existe API pública general garantizada.
- No controla automáticamente reproducción de YouTube Music: abre la búsqueda.
- No permite abrir cualquier aplicación por voz: tres apps incluidas.
- La respuesta a WhatsApp depende de la notificación activa; no hay acceso al historial de chats.
- El envío mediante PendingIntent no garantiza entrega al destinatario; la voz confirma que se envió la acción, no lectura ni entrega.
- No desbloquea ni almacena PIN, no usa accesibilidad para eludir bloqueo.
- No se ha compilado ni probado físicamente en este entorno. GitHub Actions realizará la compilación real.

## Requisitos
Android SDK 35, Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, Kotlin 2.1.20. `gradle/actions/setup-gradle` instala Gradle en CI, así que no se requiere wrapper binario.

## Pruebas antes de conducir
Instala la APK debug; concede permisos; activa MotoVoice en Ajustes → Acceso a notificaciones; conecta el intercomunicador; inicia el servicio con pantalla encendida; bloquea el teléfono y verifica llamadas, mensajes, dictado y audio en un lugar seguro y estacionado. Desactiva optimización de batería solo si es necesario y comprueba consumo. No manipules la pantalla mientras conduces.
