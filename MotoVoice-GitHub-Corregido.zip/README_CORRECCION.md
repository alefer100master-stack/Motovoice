MotoVoice corregido

Corrección: MainActivity.kt usa isFillViewport = true en ScrollView.

Para repositorios que guardan únicamente el ZIP: reemplaza el archivo MotoVoice-GitHub.zip por este archivo (renómbralo a MotoVoice-GitHub.zip en GitHub si hace falta). Conserva el workflow main.yml que ya extrae el ZIP. El workflow android.yml incluido dentro del ZIP es una referencia para copiar a .github/workflows si se desea. No se ejecutó una compilación Android completa en este entorno.
